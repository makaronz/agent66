import http from 'k6/http';
import { sleep, check } from 'k6';

export const options = {
  vus: 5,
  duration: '1m',
  thresholds: {
    http_req_duration: ['p(95)<150'],
    http_req_failed: ['rate<0.02'],
  },
};

export default function () {
  const url = __ENV.SMC_API_URL || 'https://staging.example.com/api/healthz';
  const res = http.get(url);
  check(res, { 'status is 200': (r) => r.status === 200 });
  sleep(1);
}
