# Checklist: Release Gate (SLO + ASVS)

- [ ] Testy jednostkowe/integracyjne > 80% dla krytycznych modułów.
- [ ] Brak HIGH/CRITICAL w skanie Trivy.
- [ ] SBOM wygenerowany (CycloneDX) i zarchiwizowany jako artefakt.
- [ ] Obrazy podpisane (cosign keyless).
- [ ] ZAP (DAST) baseline: brak blockerów (false positives zignorowane w wyjątki).
- [ ] SLI/SLO green (p95 < próg), budżet błędów OK.
