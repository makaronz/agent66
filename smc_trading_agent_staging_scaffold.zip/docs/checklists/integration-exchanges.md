# Checklist: Integracje — giełdy

- [ ] Limity i retry (exponential backoff + jitter).
- [ ] Idempotency keys dla POST/PUT.
- [ ] Reconnect WS < 24h, ping/pong, resubscribe.
- [ ] Obsługa losowego `TIMEOUT` i `UNKNOWN` status (Binance).
- [ ] Testy kontraktowe (mocki + testnet).
