# Checklist: Deploy K8s (staging)

- [ ] Namespace i NetworkPolicy (default deny) utworzone.
- [ ] RBAC least‑privilege.
- [ ] Probes: liveness/readiness/startup.
- [ ] Requests/Limits ustawione, HPA + PDB skonfigurowane.
- [ ] Telemetria (OTLP) działa, dashboardy widoczne.
