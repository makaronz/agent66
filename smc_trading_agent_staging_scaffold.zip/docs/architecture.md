# Architektura — przegląd

## Kontekst (System)
```mermaid
flowchart TB
  user(Trader/Quant) -->|HTTP/WebSocket| bff[Express BFF]
  bff --> fe[React Frontend]
  fe -->|REST| api[FastAPI Backend]
  api -->|gRPC/HTTP| engine[Rust Execution Engine]
  api --> db[(PostgreSQL/ClickHouse)]
  engine -->|REST/WS| exchanges[[Binance / Bybit / OANDA]]
  subgraph Observability
    ocol[OpenTelemetry Collector] --> prom[Prometheus]
    prom --> graf[Grafana]
    prom --> alert[Alertmanager]
  end
  api -->|OTLP| ocol
  engine -->|OTLP| ocol
  bff -->|OTLP| ocol
```

## Przepływ zlecenia (skrót)
```mermaid
sequenceDiagram
  participant FE as Frontend
  participant API as FastAPI
  participant ENG as Rust Engine
  participant EX as Exchange
  FE->>API: POST /orders
  API->>ENG: placeOrder(request)
  ENG->>EX: REST create order
  EX-->>ENG: ack / status
  ENG-->>API: result(status/fill)
  API-->>FE: 200 OK
```

### Zasady projektowe
- Telemetria: traces/metrics/logs via **OpenTelemetry** (OTLP) → **Prometheus/Grafana/Alertmanager**.
- Bezpieczeństwo: RBAC, NetworkPolicies, TLS, audyt.
- Niezawodność: HPA, PDB, readiness/liveness/startup probes.
