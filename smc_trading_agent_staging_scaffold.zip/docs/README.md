# SMC Trading Agent — Dokumentacja (staging)

Ten katalog zawiera dokumentację architektury, runbooki, checklisty oraz artefakty „ready-to-use” pod środowisko **staging**.

## Szybki start
1. Zainstaluj wymagane narzędzia: `helm`, `kubectl`, `k6`, `cosign`, `trivy`, `node` (dla `cdxgen`), `python3`.
2. Skonfiguruj kontekst K8s na klastrze staging (`KUBECONFIG` / `kubectl config use-context ...`).
3. Utwórz przestrzeń nazw i polityki (Terraform `terraform/envs/staging`).
4. Uruchom CI/CD (`.github/workflows/build_scan_sign_deploy_staging.yml`).

## Zawartość
- `architecture.md` — diagramy i opis komponentów.
- `context-7.md` — szablon analizy Context‑7.
- `risk-register.md` — rejestr ryzyk i mitgacje.
- `slo-sla.md` — SLI/SLO i polityka budżetu błędów.
- `runbooks/` — procedury operacyjne (incydenty, DR, rotacja kluczy, reconnect WS).
- `checklists/` — check‑listy releasowe, K8s i integracyjne.
- `observability/` — konfiguracje Prometheus alert rules i OpenTelemetry Collector.
