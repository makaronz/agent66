# Runbook: Incydenty P1–P3

## Klasyfikacja
- **P1**: brak handlu / brak dostępu do API, dane krytyczne niedostępne.
- **P2**: degradacja wydajności (p95 > 2×SLO), sporadyczne błędy.
- **P3**: drobne odchylenia, brak wpływu na handel.

## Procedura (P1 skrót)
1. On‑call (5 min): triage, potwierdzenie wpływu (SLO/SLA).
2. Rollback/canary disable jeśli regresja wydania.
3. Komunikacja: status, ETA, kanał #status.
4. Mitigacje: scale‑out (HPA), circuit breakers, feature flags.
5. Post‑mortem w 48h, min. 1 P0 action item.
