# Runbook: Disaster Recovery (DR)

- **RTO**: 60 min, **RPO**: 15 min.
- Backup DB: snapshoty (min. co 15 min) + test odtworzeniowy 1×/miesiąc.
- Procedura:
  1. Ocena zakresu (DB/compute/network).
  2. Przywrócenie storage i tajemnic (Vault/KMS).
  3. Redeploy release N-1 poprzez Helm + wartości DR.
  4. Walidacja integralności (checksumy), smoke testy, health checks.
