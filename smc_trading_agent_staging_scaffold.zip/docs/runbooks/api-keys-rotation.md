# Runbook: Rotacja kluczy API (exchanges)

1. Generuj nowe klucze (minimalny scope, IP allowlist).
2. Zapisz w Secret Manager (Vault/KMS), **nie** w repo/TF state.
3. Rolling restart komponentów konsumujących sekrety.
4. Walidacja: `/healthz` OK, test order na sandboxie.
5. Revoke starych kluczy i potwierdzenie audytowe.
