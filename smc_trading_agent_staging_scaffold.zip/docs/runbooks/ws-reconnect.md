# Runbook: Reconnect WebSocket (Binance/Bybit/OANDA)

- Utrzymuj heartbeat/ping-pong.
- Limit 24h na połączenie (Binance): wymuś rekonekt < 24h.
- Backoff z jitter, re‑subskrypcja kanałów po wznowieniu.
- Idempotency dla zdarzeń (deduplikacja po `eventTime`/`updateId`).

Pseudo‑kod backoff:
```
delay = base * (2 ** retries) + random(0, jitter)
sleep(delay)  # z maksymalnym limitem
```
