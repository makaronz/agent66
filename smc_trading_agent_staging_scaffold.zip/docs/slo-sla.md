# SLI/SLO i polityka budżetu błędów (staging→prod)

- **SLI dostępności API**: 99.9% (p95 latency < 150ms dla ścieżek krytycznych).
- **SLO**: 99.9% miesięcznie; budżet błędów = 0.1%.
- **Polityka**: jeśli zużycie budżetu > 20% w 4 tyg., obowiązkowy post‑mortem; przy wyczerpaniu — change freeze do czasu poprawy.

## Przykładowe SLI
- `http_request_duration_seconds` (histogram) p95/p99.
- `5xx_rate` (procent błędów).
- `ws_reconnects_total` (stabilność kanałów).
