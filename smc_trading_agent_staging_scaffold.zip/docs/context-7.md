# Analiza Context‑7 — szablon do wypełnienia

## 1. Biznes
- Cele, KPI (Sharpe, Sortino, Max Drawdown, Hit Rate, Latency-to-Fill, Slippage).
- Model przychodów (sub, fee share).
- Ryzyka biznesowe i ich mierniki.

## 2. Użytkownik
- Persony, use‑cases, journey (onboarding API keys, backtest, paper→live).
- Wymagania dostępności (WCAG), tryb low‑bandwidth.

## 3. System
- Granice systemu, systemy zewnętrzne, polityki danych (PII, retencja, RODO).

## 4. Kod
- Repo, stacki (Py/Rust/Node/React), style, testy, pokrycie, SAST/DAST.

## 5. Dane
- Modele: sygnały SMC, order book, trades/klines, konto.
- Schematy DB, migracje, DPIA (jeśli wymagana).

## 6. Operacje
- Deployment (K8s), HA/DR, observability (OTel, Prometheus, Grafana), koszty.

## 7. Ryzyko
- Security (OWASP ASVS), compliance (NIST), privacy (GDPR), vendor lock‑in.
