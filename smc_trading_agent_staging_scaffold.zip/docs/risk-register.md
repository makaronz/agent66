# Rejestr ryzyk (wycinek)

| ID | Kategoria | Ryzyko | Prawd. | Impact | Mitigacja | Owner | Status |
|----|-----------|--------|--------|--------|-----------|-------|--------|
| R-01 | Bezpieczeństwo | Wycieki kluczy API | M | W | Vault/KMS, rotacja, least-privilege | SecEng | Otwarte |
| R-02 | Wydajność | Latencja > p95 SLO | M | W | Profiling, HPA, optymalizacje Rust | Perf TL | Otwarte |
| R-03 | Integracje | Disconnect WS/24h limit | W | Ś | Reconnect z jitter, backoff, idempotency | Eng Lead | Otwarte |
