#!/usr/bin/env bash
set -euo pipefail

if ! command -v cdxgen >/dev/null 2>&1; then
  echo "Installing cdxgen (npm)..." >&2
  npm i -g @cyclonedx/cdxgen
fi

mkdir -p sbom
cdxgen -o sbom/monorepo.cdx.json -t auto -r .
echo "SBOM zapisany w sbom/monorepo.cdx.json"
