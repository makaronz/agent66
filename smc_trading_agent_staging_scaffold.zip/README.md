# SMC Trading Agent — Staging Scaffold

Wstępny szkielet repozytorium do wdrożenia środowiska **staging** z CI/CD, SBOM, skanowaniem podatności, podpisywaniem obrazów i deployem Helm na Kubernetes.

> Data wygenerowania: 2025-08-14T00:31:00.048215Z

## Jak używać
1. Provision K8s namespace i polityki: `cd terraform/envs/staging && terraform init && terraform apply`.
2. Ustaw sekret `KUBECONFIG_STAGING` (zawartość kubeconfig) w GitHub Secrets repo.
3. Opcjonalnie: `ZAP_TARGET_URL` na adres staging (np. `https://staging.example.com`).
4. Wypchnij gałąź `staging` — pipeline zbuduje, przeskanuje, podpisze obrazy i wdroży release.
5. Uruchom `k6/smoke.js` lokalnie lub przez workflow.

## Ważne
- **Sekrety exchange** trzymaj w **Vault/KMS**, nie w TF state / repo.
- Dostosuj wartości Helm (`helm/values/staging/*.yaml`) oraz progi alertów w Prometheus.
- Uzupełnij `docs/context-7.md` i `docs/risk-register.md`.

## Struktura
- `docs/` — dokumentacja, runbooki, checklisty, observability.
- `helm/` — cztery charty usług (FastAPI, Rust Engine, Express BFF, React FE).
- `terraform/` — definicje namespaces, quotas, NetworkPolicy (staging).
- `.github/workflows/` — CI/CD (build+scan+sign+deploy), ZAP DAST, k6 smoke.
- `k6/` — przykład smoke testu.
- `scripts/` — generowanie SBOM.
